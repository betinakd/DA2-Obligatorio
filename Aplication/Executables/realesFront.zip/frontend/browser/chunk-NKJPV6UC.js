import{kd as a}from"./chunk-TGIRW23N.js";export{a as CreateComponent};
